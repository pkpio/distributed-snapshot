# distributed-snapshot
Snapshot-Algorithm by Chandy and Lamport
