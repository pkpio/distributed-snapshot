/**
 * 
 */
package com.tk.ds.ui;

/**
 * @author Ram
 *
 */
public interface UiUpdatesListner {
	public void updateAccountBalance(int accountBalance, int accountNumber);
	public void updateInfo(String info);
}
